import pandas as pd
import numpy as np
from random import shuffle

class DecisionTreeNode:
    def __init__(self, depth, feature, feature_index, feature_is_continuous, continuous_value = 0):
        """
        初始化
        """
        self.depth = depth
        self.feature = feature
        self.feature_index = feature_index
        self.feature_is_continuous = feature_is_continuous
        self.continuous_value = continuous_value
        self.sons = dict()

        self.leaf_tag = None

class XGDecisionTree:
    def __init__(self, data, G, H, gamma, lambd, maxDepth = 100, min_sample = 1):
        self.data = data
        self.G = pd.DataFrame(G)
        self.H = pd.DataFrame(H)

        self.gamma = gamma
        self.lambd = lambd

        self.maxDepth = maxDepth
        self.min_sample = min_sample

        self.features = list(data.iloc[:, :-1].columns)
        self.x = data.iloc[:, :-1]
        self.y = data.iloc[:, -1]

        self.is_continuous = []
        for feature in self.features:
            if (self.data[feature].dtype == "float" or self.data[feature].dtype == "int" or self.data[feature].dtype == "int64"):
                if (len(set(self.data[feature])) > 0.3 * len(self.data)) or len(set(self.data[feature])) > 10:
                    self.is_continuous.append(True)
                else:
                    # print(len(set(self.data[feature])))
                    self.is_continuous.append(False)
            else:
                # print(self.data[feature].dtype)
                self.is_continuous.append(False)

        self.dic = dict()
        self.root = None

    def get_best_split(self, data, G, H, columns):
        """
        data
            试分裂节点的数据
        G, H
            data 对应的一阶导和二阶导
        obj_old
            节点分裂之前的obj
        columns
            分裂节点选择的参考属性

        :return
            如果分裂的时候选择的特征是连续的 返回 分裂特征下标 分裂特征值 分裂完左叶子节点对应数据下标index_l 右叶子对应数据下标index_r 新的obj
            如果分裂的时候选择的特征是离散的 返回 分裂特征下标 新的obj
        """
        G_, H_ = float(G.sum()), float(H.sum())
        obj_old = self.gamma - 0.5 * G_**2 / (H_ + self.lambd)
        l = len(columns)
        clms = columns.copy()
        # 如果属性大于5个 就让l折半
        if l >= 5:
            l = l // 2
            shuffle(clms)
        # 划分后的 obj值，这里是做了一个舒适化
        obj_new = 2 * self.gamma
        # 左节点数据索引 右节点数据索引
        index_l, index_r = None, None
        w_l, w_r = None, None
        # 划分属性 划分值（如果是连续属性）
        split_column, split_value = clms[0], 0
        # 随机取l个属性
        for feature_index in clms[:l]:
            feature_name = self.features[feature_index]
            # 如果特征是连续的
            if self.is_continuous[feature_index]:
                # 为了保证效率，只取几个分位数
                sorted_values = []
                for i in range(1, 10, 2):
                    sorted_values.append(float(data[feature_name].quantile(i / 10)))
                # sorted_values = list(set(data[feature_name]))
                # sorted_values.sort()
                for j in range(len(sorted_values) - 1):
                    ind_l, ind_r = data[feature_name] <= sorted_values[j], data[feature_name] > sorted_values[j]
                    G_L, H_L = float(G[ind_l].sum()), float(H[ind_l].sum())
                    G_R, H_R = G_ - G_L, H_ - H_L
                    # 计算这种划分下的 obj
                    obj_t = 2 * self.gamma - 0.5 * (G_L**2 / (H_L + self.lambd) + G_R**2 / (H_R + self.lambd))
                    # 如果该种划分是目前最优的就记录下来，更新obj、左右节点数据索引和权重、划分属性和划分值
                    if obj_t < obj_new:
                        obj_new = obj_t
                        index_l, index_r = ind_l, ind_r
                        w_l, w_r = -G_L / (H_L + self.lambd), -G_R / (H_R + self.lambd)
                        split_column, split_value = feature_index, sorted_values[j]
            # 如果特征是离散的
            else:
                cat_feature = set(list(self.data[feature_name]))
                obj_t = len(cat_feature) * self.gamma
                for feature in cat_feature:
                    # 每个特征值会引出一个新的叶子节点，要计算每个新的叶子节点的obj
                    ind = data[feature_name] == feature
                    G_t, H_t = float(G[ind].sum()), float(H[ind].sum())
                    obj_t -= 0.5 * (G_t**2 / (H_t + self.lambd))
                # 如果该种划分是目前最优的就记录下来，更新obj、划分属性
                if obj_t < obj_new:
                    obj_new = obj_t
                    split_column = feature_index

        # 上面找出了最好的分裂方案
        if obj_old <= obj_new:
            # 这说明不分裂是比较好的选择
            return None

        else:
            #选择的特征是连续的 返回 分裂特征下标 分裂特征值 分裂完左叶子节点对应数据下标index_l 右叶子对应数据下标index_r 新的obj
            if self.is_continuous[split_column]:
                return split_column, split_value, index_l, index_r, obj_new
            #选择的特征是离散的 返回 分裂特征下标 新的obj
            else:
                return split_column, obj_new

    def createXGTree_(self, data, G, H, columns, depth, dic = None):
        """
        该函数实现递归的方式建树
        node
            处理的节点
        data
            当前处理节点对应的数据
        G, H
            data对应的一阶导二阶导G、H
        lambd gamma
            XGBoost的参数
        columns
            可用的特征
        dic
            决策树对应的字典
        :return:
        """
        G_, H_ = float(G.sum()), float(H.sum())

        f = self.get_best_split(data, G, H, columns)
        # 如果得到了  空值  样本数量小于min_sample     深度超过了MaxDepth
        if type(f) == type(None) or len(data) <= self.min_sample or depth > self.maxDepth:
            return - G_ / (H_ + self.lambd)

        elif self.is_continuous[f[0]]:
            node = DecisionTreeNode(depth, self.features[f[0]], f[0], True, f[1])

            data_l, data_r = data[f[2]], data[f[3]]
            G_l, G_r = G[f[2]], G[f[3]]
            H_l, H_r = H[f[2]], H[f[3]]

            node.sons[f"<={f[1]}"] = self.createXGTree_(data_l, G_l, H_l, columns, depth + 1)
            node.sons[f">{f[1]}"] = self.createXGTree_(data_r, G_r, H_r, columns, depth + 1)

            return node

        else:
            feature_name = self.features[f[0]]
            node = DecisionTreeNode(depth, self.features[f[0]], f[0], False)
            cat_feature = set(list(data[feature_name]))
            # obj_t = len(cat_feature) * self.gamma

            columns.remove(f[0])
            for feature in cat_feature:
                # 每个特征值会引出一个新的叶子节点，要计算每个新的叶子节点的obj
                ind = data[feature_name] == feature
                G_t, H_t = G[ind], H[ind]

                node.sons[feature] = self.createXGTree_(data[ind], G_t, H_t, columns, depth + 1)

            return node

    def createXGTree(self):
        self.root = self.createXGTree_(self.data, self.G, self.H, [i for i in range(len(self.features))], 1)


    def predict_(self, x, root):
        """
        接收预测测样本，输出预测值
        """
        x = pd.DataFrame(x, columns = self.features)
        length_x = len(x)

        ans = []
        for i in range(length_x):
            node = root
            while True:
                if not isinstance(node, DecisionTreeNode):
                    break

                if node.feature_is_continuous:
                    if x.iloc[i, node.feature_index] <= node.continuous_value:
                        node = node.sons[f"<={node.continuous_value}"]
                    else:
                        node = node.sons[f">{node.continuous_value}"]

                else:
                    node = node.sons[x.iloc[i, node.feature_index]]

            ans.append(node)
        return ans

    def predict(self, x):
        return self.predict_(x, self.root)

    def get_accuracy_(self, data, node):
        pre = self.predict_(data.iloc[:, :-1], node)
        d = list(data.iloc[:, -1])
        cor = 0
        for i in range(len(pre)):
            if pre[i] >= 0 and d[i] == 1:
                cor = cor + 1
            elif pre[i] < 0 and d[i] == -1:
                cor += 1

        print(cor, "out of", len(d))
        return cor, pre

    def get_accuracy(self, data):
        return self.get_accuracy_(data, self.root)

def process_data(data, label):
    data = data.copy()
    for i in range(len(data)):
        if data.iloc[i, -1] == label:
            data.iloc[i, -1] = 1
        else:
            data.iloc[i, -1] = -1
    return data

# G = [1, 2, 3, 4]
# d = pd.DataFrame(G)
# ind = d[0] < 4
# print(d[ind])
# print(d[0] < 3, d < 3)
#
# a = [34, 23, 95, 2]
# a.remove(95)
# print(a)

print(DecisionTreeNode.__name__)

# watermelon_data = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\watermelon3_0.csv")
# watermelon_data = watermelon_data.iloc[:, 7:]
# watermelon_data["好瓜"] = watermelon_data["好瓜"].map({"是": 1, "否": -1})
# print(watermelon_data)
#
# G, H = -2 * watermelon_data["好瓜"], [2 for i in range(17)]
# xg = XGDecisionTree(watermelon_data, G, H, 5, 0.5)
#
# xg.createXGTree()
# print(xg.predict((watermelon_data.iloc[:, :-1])))
# xg.get_accuracy(watermelon_data)
#
# names = [f"feature{i}" for i in range(64)]
# names.append("class")
# data2 = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTrain.csv", names = names)
# data_val = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTest.csv", names = names)
# data = process_data(data2, 0)
# # data = data2
# G , H = -2 * data["class"], [2 for i in range(len(data))]
# xgb = XGDecisionTree(data, G, H, 5, 0.5)
# xgb.createXGTree()
# xgb.get_accuracy(data)