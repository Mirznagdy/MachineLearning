import pandas as pd
import numpy as np
from math import log, exp
import random
from sklearn import tree

class DecisionTreeNode:
    def __init__(self, feature, feature_index, feature_is_continuous, continuous_value = 0):
        """
        初始化
        """
        self.feature = feature
        self.feature_index = feature_index
        self.feature_is_continuous = feature_is_continuous
        self.continuous_value = continuous_value
        self.sons = dict()

        self.leaf_tag = None

class DecisionTree:
    def __init__(self, data):
        self.data = data
        self.features = list(data.iloc[:, :-1].columns)
        self.x = data.iloc[:, :-1]
        self.y = data.iloc[:, -1]

        self.is_continuous = []
        for feature in self.features:
            if (self.data[feature].dtype == "float" or self.data[feature].dtype == "int" or self.data[feature].dtype == "int64"):
                if (len(set(self.data[feature])) > 0.3 * len(self.data)) or len(set(self.data[feature])) > 10:
                    self.is_continuous.append(True)
                else:
                    # print(len(set(self.data[feature])))
                    self.is_continuous.append(False)
            else:
                # print(self.data[feature].dtype)
                self.is_continuous.append(False)

        self.dic = dict()

    def info_entropy(self, data_y):
        labels = set(list(data_y))
        y_num = len(data_y)
        Ent_D = 0
        for label in labels:
            pk = len(data_y.loc[data_y == label])
            pk = pk / y_num
            Ent_D = Ent_D - (pk * log(pk, 2))
        return Ent_D

    def Gain(self, data, features_index, Gain_ratio = False):
        """
        该函数接受数据集 返回信息增益最大的属性
        """
        Ent_D = self.info_entropy(data.iloc[:, -1])
        length_data = len(data)
        max_gain = 0
        max_gain_feature_index = features_index[0]
        max_gain_continuous = 0
        for i in features_index:
            feature_name = self.features[i]
            sum_ = 0
            #如果特征是连续的
            if self.is_continuous[i]:
                sorted_values = list(set(data[feature_name]))
                sorted_values.sort()
                for j in range(len(sorted_values) - 1):
                    _sum = 0
                    v = (sorted_values[j] + sorted_values[j + 1]) / 2
                    _sum = _sum + len(data.loc[data[feature_name] <= v]) / length_data * self.info_entropy(data.loc[data[feature_name] <= v].iloc[:,-1]) + len(data.loc[data[feature_name] > v]) / length_data * self.info_entropy(data.loc[data[feature_name] > v].iloc[:,-1])

                    IV_a = -len(data.loc[data[feature_name] <= v]) / length_data * log(len(data.loc[data[feature_name] <= v]) / length_data, 2) - len(data.loc[data[feature_name] > v]) / length_data * log(len(data.loc[data[feature_name] > v]) / length_data, 2)
                    # print(self.info_entropy(data.iloc[:, -1]) - _sum, feature_name, v)
                    # print(_sum, feature_name, v, IV_a)
                    gain = Ent_D - _sum
                    if Gain_ratio == True:
                        if IV_a == 0:
                            IV_a = 0.00001
                        gain = gain / IV_a

                    if gain > max_gain:
                        max_gain = gain
                        max_gain_feature_index = i
                        max_gain_continuous = v

            # 如果特征是离散的
            else:
                IV_a = 0
                cat_feature = set(list(data[feature_name]))
                for feature in cat_feature:
                    num = len(data[data[feature_name] ==feature])
                    sum_ = sum_ + num / length_data * self.info_entropy(data.loc[data[feature_name] == feature].iloc[:, -1])

                    IV_a = IV_a - num / length_data * log(num / length_data, 2)
                # print(self.info_entropy(data.iloc[:, -1]) - sum_, feature_name)
                # print(sum_, feature_name, IV_a)
                gain = Ent_D - sum_
                if Gain_ratio == True:
                    if IV_a == 0:
                        IV_a = 0.00001
                    gain = gain / IV_a

                if gain > max_gain:
                    max_gain = gain
                    max_gain_feature_index = i
        if self.is_continuous[max_gain_feature_index]:
            return self.features[max_gain_feature_index], max_gain_feature_index, True, max_gain_continuous
        else:
            return self.features[max_gain_feature_index], max_gain_feature_index, False

    def best_col(self, data, features_index, method = "Gain"):
        """
        该函数接受数据集和划分的方法，返回最有属性及其下标 是否连续等
        """
        # 最大信息增益 ID3
        if method == "Gain":
            return self.Gain(data, features_index)

        # 信息增益率  C4.5
        elif method == "Gain_ratio":
            return self.Gain(data, features_index, True)

        # 基尼指数
        else:
            min_gini = 1000
            min_gini_feature_index = features_index[0]
            min_gini_continuous = 0

            length_data = len(data)
            for i in features_index:
                feature_name = self.features[i]

                if self.is_continuous[i] == True:
                    sorted_values = list(set(data[feature_name]))
                    sorted_values.sort()
                    for j in range(len(sorted_values) - 1):
                        v = (sorted_values[j] + sorted_values[j + 1]) / 2

                        d1, d2 = data.loc[data[feature_name] <= v].iloc[:, -1], data.loc[data[feature_name] > v].iloc[:, -1]
                        length_d1, length_d2 = len(d1), len(d2)
                        d1_list, d2_list = list(set(d1)), list(set(d2))

                        gini1, gini2 = 1, 1
                        for k in d1_list:
                            gini1 = gini1 - (len(d1.loc[d1 == k]) / length_d1) ** 2
                        for k in d2_list:
                            gini2 = gini2 - (len(d2.loc[d2 == k]) / length_d2) ** 2

                        if length_d1 / length_data * gini1 + length_d2 / length_data * gini2 < min_gini:
                            min_gini = length_d1 / length_data * gini1 + length_d2 / length_data * gini2
                            min_gini_feature_index = i
                            min_gini_continuous = v

                else:
                    gini = 0
                    values = list(set(self.data[feature_name]))

                    for value in values:
                        g = 1
                        d = data.loc[data[feature_name] == value].iloc[:, -1]
                        length_d = len(d)
                        k_list = list(set(d))
                        for k in k_list:
                            g = g - (len(d.loc[d == k]) / length_d) ** 2

                        gini = gini + length_d / length_data * g

                    if gini < min_gini:
                        min_gini = gini
                        min_gini_feature_index = i

        if self.is_continuous[min_gini_feature_index] == True:
            return self.features[min_gini_feature_index], min_gini_feature_index, True, min_gini_continuous

        else:
            return self.features[min_gini_feature_index], min_gini_feature_index, False

    def accurate_num(self, y_hat, y):
        cor = 0
        for i in range(len(y)):
            if y_hat == y[i]:
                cor = cor + 1
        return cor

    def is_prep_better(self, default_label, val_data, f, train_data):
        """
        判断是否需要预剪枝
        """
        before_partition = self.accurate_num(y_hat=default_label, y=list(val_data.iloc[:, -1]))
        after_partition = 0
        # 离散属性
        if f[2] == False:
            values = list(set(self.data[f[0]]))
            for value in values:
                partition_train_data, partition_val_data = train_data.loc[train_data[f[0]] == value], val_data.loc[val_data[f[0]] == value]

                if len(partition_train_data) == 0:
                    dl = default_label
                    after_partition = after_partition + self.accurate_num(y_hat=dl, y=list(partition_val_data.iloc[:, -1]))
                else:
                    dl = partition_train_data.iloc[:, -1].value_counts().idxmax()
                    after_partition = after_partition + self.accurate_num(y_hat=dl, y=list(partition_val_data.iloc[:, -1]))
        else:
            partition_train_data_1, partition_train_data_2 = train_data.loc[train_data[f[0]] <= f[3]], train_data.loc[train_data[f[0]] > f[3]]
            partition_val_data_1, partition_val_data_2 = val_data.loc[val_data[f[0]] <= f[3]], val_data.loc[val_data[f[0]] > f[3]]
            dl1, dl2 = partition_train_data_1.iloc[:, -1].value_counts().idxmax(), partition_train_data_2.iloc[:,-1].value_counts().idxmax()

            after_partition = after_partition + self.accurate_num(dl1, list(
                partition_val_data_1.iloc[:, -1])) + self.accurate_num(dl2, list(partition_val_data_2.iloc[:, -1]))

        if after_partition <= before_partition:
            return True

        else:
            return False


    def createRoot(self, method = "Gain"):
        f = self.best_col(self.data, [i for i in range(len(self.features))], method)
        self.root = DecisionTreeNode(*f)

        return f[1]
    def createDTree(self, data, columns, father, dic = None, method = "Gain", pre_pruning = False, val_data = None):
        """
        构建决策树
        """
        default_label = data.iloc[:, -1].value_counts().idxmax()

        #如果父节点特征连续
        if father.feature_is_continuous:
            D_v1, D_v2 = data.loc[data[father.feature] <= father.continuous_value], data.loc[data[father.feature] > father.continuous_value]

            if len(set(D_v1.iloc[:, -1])) == 1:
                father.sons[f"<={father.continuous_value}"] = D_v1.iloc[0, -1]
                dic[f"<={father.continuous_value}"] = D_v1.iloc[0, -1]
            if len(set(D_v2.iloc[:, -1])) == 1:
                father.sons[f">{father.continuous_value}"] = D_v2.iloc[0, -1]
                dic[f">{father.continuous_value}"] = D_v2.iloc[0, -1]

            if len(set(D_v1.iloc[:, -1])) > 1:
                f = self.best_col(D_v1, columns, method)
                # 如果要预剪枝
                if pre_pruning:
                    val_D_v1 = val_data.loc[val_data[father.feature] <= father.continuous_value]

                    dl = D_v1.iloc[:, -1].value_counts().idxmax()
                    if self.is_prep_better(dl, val_D_v1, f, D_v1):
                        father.sons[f"<={father.continuous_value}"] = dl
                        dic[f"<={father.continuous_value}"] = dl
                        print("cut a branch!")
                    else:
                        father.sons[f"<={father.continuous_value}"] = DecisionTreeNode(*f)
                        dic[f"<={father.continuous_value}"] = dict()
                        dic[f"<={father.continuous_value}"][f[0]] = dict()

                        self.createDTree(D_v1, columns, father.sons[f"<={father.continuous_value}"],dic[f"<={father.continuous_value}"][f[0]], method, pre_pruning = True, val_data = val_D_v1)

                else:
                    father.sons[f"<={father.continuous_value}"] = DecisionTreeNode(*f)
                    dic[f"<={father.continuous_value}"] = dict()
                    dic[f"<={father.continuous_value}"][f[0]] = dict()

                    self.createDTree(D_v1, columns, father.sons[f"<={father.continuous_value}"], dic[f"<={father.continuous_value}"][f[0]])

            if len(set(D_v2.iloc[:, -1])) > 1:
                f = self.best_col(D_v2, columns, method)

                # 如果要预剪枝
                if pre_pruning:
                    val_D_v2 =  val_data.loc[val_data[father.feature] > father.continuous_value]
                    dl = D_v2.iloc[:, -1].value_counts().idxmax()
                    if self.is_prep_better(dl, val_D_v2, f, D_v2):
                        father.sons[f">{father.continuous_value}"] = dl
                        dic[f">{father.continuous_value}"] = dl
                        print("cut a branch")
                    else:
                        father.sons[f">{father.continuous_value}"] = DecisionTreeNode(*f)
                        dic[f">{father.continuous_value}"] = dict()
                        dic[f">{father.continuous_value}"][f[0]] = dict()

                        self.createDTree(D_v2, columns, father.sons[f">{father.continuous_value}"], dic[f">{father.continuous_value}"][f[0]], method, pre_pruning=True, val_data=val_D_v2)

                else:
                    father.sons[f">{father.continuous_value}"] = DecisionTreeNode(*f)
                    dic[f">{father.continuous_value}"] = dict()
                    dic[f">{father.continuous_value}"][f[0]] = dict()


                    self.createDTree(D_v2, columns, father.sons[f">{father.continuous_value}"], dic[f">{father.continuous_value}"][f[0]], method)

        # 父节点是离散的
        else:
            a_stars = set(self.data[father.feature])
            for a_star in a_stars:
                D_v = data.loc[data[father.feature] == a_star]

                if len(D_v) == 0:
                    father.sons[a_star] = default_label
                    dic[a_star] = default_label

                elif len(set(D_v.iloc[:, -1])) == 1:
                    father.sons[a_star] = D_v.iloc[0, -1]
                    dic[a_star] = D_v.iloc[0, -1]


                else:
                    f = self.best_col(D_v, columns, method)

                    # 如果要预剪枝
                    if pre_pruning:
                        val_D_v = val_data.loc[val_data[father.feature] == a_star]
                        dl = D_v.iloc[:, -1].value_counts().idxmax()
                        if self.is_prep_better(dl, val_D_v, f, D_v):
                            father.sons[a_star] = dl
                            dic[a_star] = dl
                            print("cut a branch")
                        else:
                            father.sons[a_star] = DecisionTreeNode(*f)
                            dic[a_star] = dict()
                            dic[a_star][f[0]] = dict()
                            new_dic = dic[a_star]
                            new_dic[f[0]] = dict()
                            temp = columns.copy()
                            temp.remove(f[1])

                            self.createDTree(D_v, temp, father.sons[a_star], dic[a_star][f[0]], method, pre_pruning = True, val_data = val_D_v)

                    else:
                        father.sons[a_star] = DecisionTreeNode(*f)
                        dic[a_star] = dict()
                        dic[a_star][f[0]] = dict()
                        new_dic = dic[a_star]
                        new_dic[f[0]] = dict()
                        temp = columns.copy()
                        temp.remove(f[1])

                        self.createDTree(D_v, temp, father.sons[a_star], dic[a_star][f[0]], method)

    def createTree(self, method = "Gain", pre_pruning = False, val_data = None):
        f1 = self.createRoot(method)
        columns = [i for i in range(len(self.features))]
        if self.is_continuous[f1] == False:
            columns.remove(f1)
        self.dic[self.features[f1]] = dict()
        self.createDTree(self.data, columns, self.root, self.dic[self.features[f1]], method, pre_pruning, val_data)
        print("建树完成")


    def post_pruning_(self, node, data):
        """

        :param node:
        :param data:
        :return:
        """
        keys = node.sons.keys()
        for key in keys:
            if type(node.sons[key]) != type(node):
                pass
            else:
                if str(key)[0] == "<":
                    self.post_pruning_(node.sons[key], data.loc[data[node.feature] <= float(key[2:])])
                elif str(key)[0] == ">":
                    self.post_pruning_(node.sons[key], data.loc[data[node.feature] > float(key[1:])])
                else:
                    self.post_pruning_(node.sons[key], data.loc[data[node.feature] == key])

                if node.sons[key].leaf_tag != None:
                    node.sons[key] = node.sons[key].leaf_tag
        if len(data) != 0:
            before_postp = self.get_accuracy_(data, node)
            default_label = data.iloc[:, -1].value_counts().idxmax()
            after_postp = self.accurate_num(default_label, list(data.iloc[:, -1]))
            print(f"after {after_postp}, before {before_postp}")
            if after_postp > before_postp:
                print(f"post cut a branch and {after_postp - before_postp} more acc")
                node.leaf_tag = default_label



    def post_pruning(self, data):
        self.post_pruning_(self.root, data)



    def predict_(self, x, root):
        """
        接收预测测样本，输出预测值
        """
        x = pd.DataFrame(x, columns = self.features)
        length_x = len(x)

        ans = []
        for i in range(length_x):
            node = root
            while True:
                if node.feature_is_continuous:
                    if x.iloc[i, node.feature_index] <= node.continuous_value:
                        node = node.sons[f"<={node.continuous_value}"]
                    else:
                        node = node.sons[f">{node.continuous_value}"]

                else:
                    node = node.sons[x.iloc[i, node.feature_index]]

                if type(node) != type(self.root):
                    break
            ans.append(node)
        return ans

    def predict(self, x):
        self.predict_(x, self.root)
    def get_accuracy_(self, data, node):
        pre = self.predict_(data.iloc[:, :-1], node)
        d = list(data.iloc[:, -1])
        cor = 0
        for i in range(len(pre)):
            if pre[i] == d[i]:
                cor = cor + 1
        print(cor, "out of", len(d))
        return cor

    def get_accuracy(self, data):
        self.get_accuracy_(data, self.root)

if __name__ == "__main__":
    # distrain = pd.read_csv("digitsTrain.csv")
    # distest = pd.read_csv("digitsTest.csv")
    distrain = pd.read_csv("watermelon3_0.csv")
    distrain = distrain.iloc[:, 1:]
    distest = pd.read_csv("watermelon3_0.csv")
    distest = distest.iloc[:, 1:]
    dt_dis = DecisionTree(distrain)
    dt_dis.createTree(method = "Gain")
    # print(dt_dis)
    dt_dis.get_accuracy(distest)
    dt_dis.post_pruning(distest)
    dt_dis.get_accuracy(distest)
    print(dt_dis.dic)
