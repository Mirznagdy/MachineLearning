import os
import shutil

path = "E:\\pythonProject\\MathorCup\\data_final"
# for root, dirs, files in os.walk(path):
#     # for name in dirs:
#     #     print("dirs", name)
#     for name in files:
#         print("files", name)

image_train_path, image_val_path, label_train_path, label_val_path = path + "\\images\\train", path + "\\images\\val", path + "\\labels\\train", path + "\\labels\\val"

def copy_file(file_path, des_path):
    if not os.path.isfile(file_path):
        print(f"{file_path} does not exits")

    else:
        fpath, fname = os.path.split(file_path)
        if not os.path.exists(des_path):
            os.mkdir(des_path)
        shutil.copy(file_path,os.path.join(des_path, fname))

        print(f"copy {file_path} to {des_path}")
image_train, image_val = "E:\\pythonProject\\MathorCup\\data_final\\train", "E:\\pythonProject\\MathorCup\\data_final\\val"
image_train_normal, image_train_pothole = "E:\\pythonProject\\MathorCup\\data_final\\train\\normal", "E:\\pythonProject\\MathorCup\\data_final\\train\\pothole"
image_val_normal, image_val_pothole = "E:\\pythonProject\\MathorCup\\data_final\\val\\normal", "E:\\pythonProject\\MathorCup\\data_final\\val\\pothole"

if not os.path.exists(image_train):
    os.mkdir(image_train)
if not os.path.exists(image_val):
    os.mkdir(image_val)

for root, dirs, files in os.walk(label_train_path):
    for name in files:
        p = os.path.join(path, label_train_path, name)
        # print(p)
        fsize = os.path.getsize(p)

        image_path = os.path.join(path, image_train_path, str(name)[:-3] + "jpg")
        if fsize > 0:
            copy_file(image_path, image_train_pothole)
        else:
            copy_file(image_path, image_train_normal)

for root, dirs, files in os.walk(label_val_path):
    for name in files:
        p = os.path.join(path, label_val_path, name)
        # print(p)
        fsize = os.path.getsize(p)

        image_path = os.path.join(path, image_val_path, str(name)[:-3] + "jpg")
        if fsize > 0:
            copy_file(image_path, image_val_pothole)
        else:
            copy_file(image_path, image_val_normal)