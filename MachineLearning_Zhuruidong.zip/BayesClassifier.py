import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score, accuracy_score
import itertools

class BayesClassifier:
    def __init__(self, data):
        self.data = data
        self.x, self.y = self.data.iloc[:, :-1], self.data.iloc[:, -1]
        self.features = self.x.columns
        self.is_continue = []

        for feature in self.features:
            if (self.x[feature].dtype == "float" or self.x[feature].dtype == "int" or self.x[feature].dtype == "int64"):
                if len(set(self.x[feature])) > 0.3 * len(self.data) or len(set(self.x[feature])) > 10:
                    self.is_continue.append(True)
                else:
                    self.is_continue.append(False)
            else:
                self.is_continue.append(False)

        self.class_num = len(set(self.y))
        self.classes = list(set(self.y))

        self.p_class = dict()
        # dic_list是列表，列表每个元素都是字典，用字典表示某类的特征取值的后验概率
        self.dic_list = [dict() for i in range(self.class_num)]
        for c in self.classes:
            # 防止小概率连乘浮点数溢出，这里取对数
            self.p_class[c] = np.log((len(self.y.loc[self.y == c]) + 1) / (len(self.y) + self.class_num))

    def fit(self):
        # 对特征进行遍历 求每个特征上取某个特征值的概率
        for i in range(len(self.features)):
            # 如果该特征是连续的
            feature_name = self.features[i]
            if self.is_continue[i]:
                # 这里要分别对每个类求
                for j in range(self.class_num):
                    # 第j类样本数据
                    part_data = self.data.loc[self.data.iloc[:, -1] == self.classes[j]]
                    # 求在feature_name属性下的均值和方差
                    mean = part_data[feature_name].mean()
                    std = part_data[feature_name].std()
                    # 加到字典里，后面预测要用
                    self.dic_list[j][feature_name] = (mean, std)
            else:
                # 求样本在feature_name特征下的所有取值可能
                features_value = list(set(self.data[feature_name]))
                # 这里仍然是对每个类别都求其概率
                for j in range(self.class_num):
                    # 构造字典
                    self.dic_list[j][feature_name] = dict()
                    d = self.dic_list[j][feature_name]
                    #第j类样本数据
                    part_data = self.data.loc[self.data.iloc[:, -1] == self.classes[j]]
                    # 条件概率的分母 因为同一特征在算条件概率的时候分母都相等 所以这里写在循环外面
                    down = len(part_data) + len(features_value)
                    # 对每个特征值都求其条件概率
                    for value in features_value:
                        up = len(part_data.loc[part_data[feature_name] == value]) + 1
                        # 防止小概率连乘浮点数溢出，这里取对数
                        d[value] = np.log(up / down)

    def predict(self, x):
        x = pd.DataFrame(x, columns=self.x.columns)
        y_pre = []
        # 遍历所有预测样本
        for i in range(len(x)):
            most_likelihood = 0
            # 这里求样本分类为第k类的条件概率
            for k in range(self.class_num):
                # 因为多个小概率连乘容易造成浮点数溢出，这里取了对数
                p_pre = self.p_class[self.classes[k]]
                for j in range(len(self.features)):
                    # 如果该特征连续
                    if self.is_continue[j]:
                        mean, std = self.dic_list[k][self.features[j]]
                        if std == 0:
                            std = 1
                        p = np.log(1 / (np.sqrt(2 * np.pi) * std) * np.exp(-(x.iloc[i, j] - mean)**2 / (2 * std**2)))
                        # 计算条件概率，取对数后连乘变连加
                        p_pre += p
                    # 特征离散
                    else:
                        # 如果该特征值在训练样本里从来没有出现过，直接赋值0就好，对各个类的影响都一样
                        if not x.iloc[i, j] in self.dic_list[k][self.features[j]]:
                            p = 0
                        else:
                            p = self.dic_list[k][self.features[j]][x.iloc[i, j]]
                        # 计算条件概率，取对数后连乘变连加
                        p_pre += p
                # 用最大的条件概率来更新估计结果
                if len(y_pre) == i:
                    y_pre.append(self.classes[k])
                    most_likelihood = p_pre
                else:
                    if p_pre > most_likelihood:
                        y_pre[i] = self.classes[k]
                        most_likelihood = p_pre
        return y_pre

    def get_metrics(self, data):
        data = pd.DataFrame(data, columns=self.data.columns)
        # 得到每个样本的估计值
        y_true = data.iloc[:, -1]
        y_pred = self.predict(data.iloc[:, :-1])

        # 计算混淆矩阵
        cm = confusion_matrix(y_true, y_pred)
        print(f"Confusion Matrix:\n{cm}")

        # 计算各项指标
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='macro')
        recall = recall_score(y_true, y_pred, average='macro')
        f1 = f1_score(y_true, y_pred, average='macro')

        print(f"Accuracy: {accuracy}")
        print(f"Precision: {precision}")
        print(f"Recall: {recall}")
        print(f"F1 Score: {f1}")

        # 绘制混淆矩阵
        plt.figure(figsize=(10, 7))
        plt.imshow(cm, interpolation='nearest', cmap='viridis')
        plt.title('Confusion Matrix')
        plt.colorbar()
        tick_marks = np.arange(len(self.classes))
        plt.xticks(tick_marks, self.classes, rotation=45)
        plt.yticks(tick_marks, self.classes)

        fmt = 'd'
        thresh = cm.max() / 2.
        for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
            plt.text(j, i, format(cm[i, j], fmt),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black",
                     fontsize=14)  # 增大字体大小

        plt.ylabel('True label')
        plt.xlabel('Predicted label')
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    # 使用示例数据
    watermelon_data = pd.read_csv("watermelon3_0.csv")
    watermelon_data = watermelon_data.iloc[:, 1:]
    BC = BayesClassifier(watermelon_data)
    BC.fit()

    print(BC.p_class, BC.dic_list)
    BC.get_metrics(watermelon_data)

    item1 = ["青绿", "蜷缩", "浊响", "清晰", "凹陷", "硬滑", "0.697", "0.460"]
    x = pd.DataFrame(item1).T
    x.columns = watermelon_data.iloc[:, :-1].columns
    print(x)

    BC.predict(pd.DataFrame(item1).T)

    # 另外一个示例
    # names = [f"feature{i}" for i in range(64)]
    # names.append("class")
    # data2 = pd.read_csv("digitsTrain.csv", names = names)
    # data_val = pd.read_csv("digitsTest.csv", names = names)
    #
    # print(data2.loc[data2["feature48"] == 8])
    #
    # B = BayesClassifier(data2)
    # B.fit()
    # B.get_metrics(data_val)
