import numpy as np
import pandas as pd
import random
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

class MyNeuralNetwork:
    def __init__(self, in_features, hidden_layer_features, output_layer_features):
        self.v = np.random.normal(0, 0.1, size=(in_features, hidden_layer_features))
        self.gama = np.zeros(hidden_layer_features).reshape(1, -1)
        self.w = np.random.normal(0, 0.1, size=(hidden_layer_features, output_layer_features))
        self.theta = np.zeros(output_layer_features).reshape(1, -1)

    def preprocess(self, data):
        for col in data.columns:
            if data[col].dtype == "object":
                values = set(data[col])
                map_dic = dict()
                tag = 0
                for value in values:
                    map_dic[value] = tag
                    tag += 1
                data[col] = data[col].map(map_dic)

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def data_loader(self, x, y):
        ind = list(range(x.shape[0]))
        random.shuffle(ind)
        if self.w.shape[1] == 1:
            y = y.reshape(-1, 1)
            for i in range(x.shape[0]):
                yield x[ind[i]], y[ind[i]]
        else:
            for i in range(x.shape[0]):
                y_ = np.zeros(self.w.shape[1])
                y_[y[ind[i]]] = 1
                yield x[ind[i]], y_

    def y_modify(self, y):
        if self.w.shape[1] == 1:
            return y.reshape(-1, 1)
        else:
            ans = np.zeros(shape=(len(y), self.w.shape[1]))
            for i in range(len(y)):
                ans[i, y[i]] = 1
            return ans

    def MSEloss(self, x, y):
        y_h = self.sigmoid(np.matmul((np.matmul(x, self.v) - self.gama), self.w) - self.theta)
        loss = (y_h - y) ** 2
        return loss.sum() / 2

    def fit_BP(self, x, y, lr, epochs=10):
        for epoch in range(epochs):
            for x_k, y_k in self.data_loader(x, y):
                alpha = np.matmul(x_k.reshape(1, -1), self.v)
                b = self.sigmoid(alpha - self.gama)
                beta = np.matmul(b, self.w)
                y_hat = self.sigmoid(beta - self.theta)
                g = y_hat * (1 - y_hat) * (y_k - y_hat)
                e = b * (1 - b) * np.matmul(self.w, g.reshape(-1, 1)).reshape(1, -1)
                self.w = self.w + lr * np.matmul(b.reshape(-1, 1), g)
                self.theta = self.theta - lr * g
                self.v = self.v + lr * np.matmul(x_k.reshape(-1, 1), e)
                self.gama = self.gama - lr * e

    def fit_ABP(self, x, y, lr, epochs=10):
        y = self.y_modify(y)
        for epoch in range(epochs):
            alpha = np.matmul(x, self.v)
            b = self.sigmoid(alpha - self.gama)
            beta = np.matmul(b, self.w)
            y_hat = self.sigmoid(beta - self.theta)
            g = y_hat * (1 - y_hat) * (y - y_hat)
            e = b * (1 - b) * np.matmul(g, self.w.T)
            self.w = self.w + lr * np.matmul(b.T, g)
            self.theta = self.theta - lr * g.sum(axis=0)
            self.v = self.v + lr * np.matmul(x.T, e)
            self.gama = self.gama - lr * e.sum(axis=0)

    def fit_DL(self, x, y, lr, epochs=10, DL=0):
        dl_v = np.zeros(shape=self.v.shape)
        dl_gama = np.zeros(shape=self.gama.shape)
        dl_w = np.zeros(shape=self.w.shape)
        dl_theta = np.zeros(shape=self.theta.shape)
        for epoch in range(epochs):
            for x_k, y_k in self.data_loader(x, y):
                alpha = np.matmul(x_k.reshape(1, -1), self.v)
                b = self.sigmoid(alpha - self.gama)
                beta = np.matmul(b, self.w)
                y_hat = self.sigmoid(beta - self.theta)
                g = y_hat * (1 - y_hat) * (y_k - y_hat)
                e = b * (1 - b) * np.matmul(self.w, g.reshape(-1, 1)).reshape(1, -1)
                dl_v = DL * dl_v - lr * np.matmul(x_k.reshape(-1, 1), e)
                dl_w = DL * dl_w - lr * np.matmul(b.reshape(-1, 1), g)
                dl_gama = DL * dl_gama + lr * e
                dl_theta = DL * dl_theta + lr * g
                self.w = self.w - dl_w
                self.theta = self.theta - dl_theta
                self.v = self.v - dl_v
                self.gama = self.gama - dl_gama

    def fit(self, data, method="BP", lr=0.01, epochs=10, DL=0.0):
        assert method == "BP" or method == "ABP" or method == "DLBP", f"没有\"{method}\"方法，可以选择BP或ABP，默认为BP"
        self.preprocess(data)
        if method == "BP":
            self.fit_BP(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]), lr, epochs)
            return self.evaluate(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))
        elif method == "ABP":
            self.fit_ABP(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]), lr, epochs)
            return self.evaluate(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))
        elif method == "DLBP":
            self.fit_DL(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]), lr, epochs, DL)
            return self.evaluate(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))

    def evaluate(self, x, y):
        y_h = self.sigmoid(np.matmul((np.matmul(x, self.v) - self.gama), self.w) - self.theta)
        y_hat = np.argmax(y_h, axis=1)
        if self.w.shape[1] == 1:
            y_hat = (y_h >= 0.5).astype(int).reshape(-1)
        accuracy = accuracy_score(y, y_hat)
        precision = precision_score(y, y_hat, average='weighted')
        recall = recall_score(y, y_hat, average='weighted')
        f1 = f1_score(y, y_hat, average='weighted')
        print(f"Accuracy: {accuracy}")
        print(f"Precision: {precision}")
        print(f"Recall: {recall}")
        print(f"F1 Score: {f1}")
        cm = confusion_matrix(y, y_hat)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm)
        disp.plot()
        plt.show()
        return accuracy

if __name__ == "__main__":
    names = [f"feature{i}" for i in range(64)]
    names.append("class")
    data_train = pd.read_csv("digitsTrain.csv", names=names)
    data_val = pd.read_csv("digitsTest.csv", names=names)
    x_val, y_val = np.array(data_val.iloc[:, :-1]), data_val.iloc[:, -1]
    a1, a1_val = [], []
    for i in range(30):
        bpnn1 = MyNeuralNetwork(64, 32, 10)
        a1.append(bpnn1.fit(data_train, method="BP", lr=0.004, epochs=10))
        a1_val.append(bpnn1.evaluate(x_val, y_val))
    print("avg acc by BP on train set", np.mean(a1))
    print("avg acc by BP on val set", np.mean(a1_val))

    a2, a2_val = [], []
    for i in range(30):
        bpnn2 = MyNeuralNetwork(64, 32, 10)
        a2.append(bpnn2.fit(data_train, method="ABP", lr=0.005, epochs=10, DL=0.42))
        a2_val.append(bpnn2.evaluate(x_val, y_val))

    print("avg acc by BPDL on train set", np.mean(a2))
    print("avg acc by BPDL on val set", np.mean(a2_val))
