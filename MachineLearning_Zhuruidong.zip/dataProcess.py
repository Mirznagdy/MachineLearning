import os
import shutil
import random

def copy_file(file_path, des_path):
    if not os.path.isfile(file_path):
        print(f"{file_path} does not exits")

    else:
        fpath, fname = os.path.split(file_path)
        if not os.path.exists(des_path):
            os.mkdir(des_path)
        if not os.path.isfile(os.path.join(des_path, fname)):
            shutil.copy(file_path,os.path.join(des_path, fname))

des_path = "E:\\pythonProject\\MathorCup\\data_final\\train\\normal"
if not os.path.exists(des_path):
    os.mkdir(des_path)

path = "E:\\pythonProject\\MathorCup\\dataset3\\labels\\train"

l = list(os.walk(path))[0][2]
# print(l)

# index = list(range(len(l)))
# random.shuffle(index)
# print(index)
# length = len(l)
#
# for i in range(1001,length):
#     copy_file(os.path.join(path, l[i]), des_path)

for i in range(len(l)):
    if i > 1100:
        p = os.path.join(path, l[i])
        # print(p)
        fsize = os.path.getsize(p)

        image_path = os.path.join("E:\\pythonProject\\MathorCup\\dataset3\\images\\train", str(l[i])[:-3] + "jpg")

        if fsize == 0:
            print(image_path)
            copy_file(image_path, des_path)
        # else:
        #     copy_file(image_path, image_train_normal)
