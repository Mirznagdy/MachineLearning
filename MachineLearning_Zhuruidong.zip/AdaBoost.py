from BaseModelDecisionTree import BaseModelDecisionTree
import numpy as np
import pandas as pd

class MyAdaBoost:
    def __init__(self, data, maxDepth = 1):
        self.data = data
        self.base_models = []
        self.alpha = []

        length_data = len(data)
        self.weights = [1 / length_data for i in range(length_data)]
        # 决策树作为基分类器 指定最大深度
        self.maxDepth = maxDepth

        self.class_num = len(set(data.iloc[:, -1]))

        self.c = None
        if self.class_num > 2:
            self.c = list(range(self.class_num))
            self.base_models, self.alpha = [[] for i in range(self.class_num)], [[] for i in range(self.class_num)]


    def process_data(self, label):
        data = self.data.copy()
        for i in range(len(data)):
            if data.iloc[i, -1] == label:
                data.iloc[i, -1] = 1
            else:
                data.iloc[i, -1] = -1
        return data

    def fit_(self, data, t, base_models, alpha):
        """
        t
            基学习器的数量
        """
        #
        weights = self.weights
        for i in range(t):
            basemodel = BaseModelDecisionTree(data, weights, self.maxDepth)
            basemodel.createTree()
            # print(basemodel.dic)
            # 获取该基学习器的误分率和更新后的权重
            epsilon_t, w_new = basemodel.get_epsilon()
            print(epsilon_t)
            # 误分率大于0.5结束过程，模型建立失败
            if epsilon_t > 0.5:
                # self.base_models, self.alpha = [], []
                print("基学习器正确率不足0.5 训练过程结束")
                return None
            else:
                # 保存基学习器 基学习器权重 更新样本权重
                base_models.append(basemodel)
                alpha.append(0.5 * np.log((1 - epsilon_t) / epsilon_t))
                weights = w_new

    def fit(self, t):
        if self.class_num == 2:
            self.fit_(self.data, t, self.base_models, self.alpha)

        else:
            w = self.weights
            for i in range(self.class_num):
                self.weights = w
                self.fit_(self.process_data(self.c[i]), t, self.base_models[i], self.alpha[i])
                print(f"基学习器{self.c[i]}构建完成")


    def predict_(self, x, base_models, alpha):
        pre = []
        for i in range(len(base_models)):
            pre.append(base_models[i].predict(x))


        y_pre = np.array(alpha).reshape(1, -1) @ np.array(pre)

        return y_pre

    def predict(self, x):

        if self.class_num == 2:
            y_pre = self.predict_(x, self.base_models, self.alpha).reshape(-1)
            for i in range(len(y_pre)):
                if y_pre[i] >= 0:
                    y_pre[i] = 1
                else:
                    y_pre[i] = -1
            return y_pre
        else:
            pre = []
            for i in range(self.class_num):
                pre.append(self.predict_(x, self.base_models[i], self.alpha[i]).reshape(1, -1))

            y_pre = np.concatenate(pre, axis = 0)

            return y_pre.argmax(axis = 0)

    def get_accuracy(self, data):
        x, y = data.iloc[:, :-1], data.iloc[:, -1]
        y_pre = self.predict(x)
        print(y_pre)
        cor = 0
        all = len(y_pre)
        for i in range(all):
            if y_pre[i] == y[i]:
                cor += 1

        print(f"{cor} out of {all}, acc {cor / all}")
        return cor / all

# watermelon_data = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\watermelon3_0.csv")
# watermelon_data = watermelon_data.iloc[:, 7:]
# watermelon_data["好瓜"] = watermelon_data["好瓜"].map({"是": 1, "否": -1})
# print(watermelon_data)

# ada = MyAdaBoost(watermelon_data, maxDepth=1)
# ada.fit(11)
#
# ada.get_accuracy(watermelon_data)

# 权重更新公式在错误率为0.5的时候不更新权重，怎么回事

# names = [f"feature{i}" for i in range(64)]
# names.append("class")
# data2 = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTrain.csv", names = names)
# data_val = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTest.csv", names = names)
#
# ada = MyAdaBoost(data2, maxDepth = 2)
# ada.fit(10)
# ada.get_accuracy(data2)
# ada.get_accuracy(data_val)

imgtrain, imgtest = pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//imageDataset//imageTrain.csv"), pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//imageDataset//imageTest.csv")
ada = MyAdaBoost(imgtrain, 3)
ada.fit(10)