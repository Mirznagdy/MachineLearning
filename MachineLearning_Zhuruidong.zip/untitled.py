import math

print(0.15071 * math.log(0.15071, 2) - 0.84929 * math.log(0.84929, 2))