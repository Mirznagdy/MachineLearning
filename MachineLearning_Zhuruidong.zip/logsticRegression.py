# coding: utf-8

import pandas as pd
import numpy as np
from numpy import linalg
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
import random


def get_train_data(data, category):
    x, y = np.array(data[data.columns[:len(data.columns) - 1]]), np.array(data[data.columns[-1]])
    x_hat = np.concatenate([x, np.ones(shape=(x.shape[0], 1))], axis=1)
    for i in range(len(y)):
        if y[i] == category:
            y[i] = 1
        else:
            y[i] = 0
    return x, y, x_hat


def train_i(data, category):
    x, y, x_hat = get_train_data(data, category)
    beta = np.zeros(shape=(x_hat.shape[1], 1))
    epoch = 0
    old_loss = 100
    error = 100
    while True:
        beta_T_x = np.matmul(beta.T, x_hat.T).reshape(-1)
        current_loss = (-1 * y * beta_T_x + np.log(1 + np.exp(beta_T_x))).sum()
        print(f"迭代第{epoch}轮, 似然函数最小值", current_loss)

        TP, FP, TN, FN = 0, 0, 0, 0
        error = 0
        ans = np.exp(np.matmul(x_hat, beta)) / (1 + np.exp(np.matmul(x_hat, beta)))
        for i in range(len(ans)):
            if ans[i] > 0.5 and y[i] == 1:
                TP = TP + 1
            elif ans[i] > 0.5 and y[i] == 0:
                FP = FP + 1
                error = error + 1
            elif ans[i] <= 0.5 and y[i] == 1:
                FN = FN + 1
                error = error + 1
            else:
                TN = TN + 1

        if np.abs(old_loss - current_loss) <= 0.00001 or error == 0:
            break

        p = (np.exp(beta_T_x) / (1 + np.exp(beta_T_x))).reshape(-1)
        dx_beta, dx2_beta = np.zeros(shape=(x.shape[1] + 1, 1)), np.zeros(shape=(x.shape[1] + 1, x.shape[1] + 1))
        for i in range(x.shape[0]):
            dx_beta = dx_beta - (x_hat[i, :] * (y[i] - p[i])).reshape(-1, 1)
            dx2_beta = dx2_beta + (np.matmul(x_hat[i:i + 1, :].T, x_hat[i:i + 1, :])) * p[i] * (1 - p[i])

        try:
            beta = beta - np.matmul(linalg.inv(dx2_beta), dx_beta)
        except:
            gama = 0.005
            beta = beta - np.matmul(linalg.inv(dx2_beta + gama * np.identity(dx2_beta.shape[0])), dx_beta)

        old_loss = current_loss
        epoch = epoch + 1

    print(f"共有{len(ans)}组数据\nTP(真正例) {TP}    FN(假反例) {FN}\nFP(假正例) {FP}    TN(真反例) {TN}")
    if TP + FP == 0:
        print(f"本次训练数据分布不合理，只有反例无正例，不适合用查准率和召回率以及F1度量值来评估模型")
    else:
        print(f"查准率 {TP / (TP + FP)}\n召回率 {TP / (TP + FN)}\nF1度量 {2 * TP / (len(y) + TP - TN)}")
    print("正确率", (len(y) - error) / len(y))
    return beta


def get_ROC(beta, x_hat, y):
    y_hat = np.exp(np.matmul(x_hat, beta)) / (1 + np.exp(np.matmul(x_hat, beta)))
    ind = np.argsort(y_hat, axis=0)[::-1]
    y = y[ind]

    TPR, FPR = [], []
    for i in range(len(y)):
        TP, FP, TN, FN = 0, 0, 0, 0
        for pos in range(0, i):
            if y[pos] == 1:
                TP = TP + 1
            else:
                FP = FP + 1
        for neg in range(i, len(y)):
            if y[neg] == 1:
                FN = FN + 1
            else:
                TN = TN + 1
        TPR.append(TP / (TP + FN))
        FPR.append(FP / (TN + FP))
    plt.figure(figsize=(3, 3))
    plt.plot(FPR, TPR)
    plt.show()


def predict(beta, x):
    x = np.concatenate([x, np.ones(shape=(x.shape[0], 1))], axis=1)
    ans = np.exp(np.matmul(x, beta)) / (1 + np.exp(np.matmul(x, beta)))
    if beta.shape[1] == 1:
        for i in range(len(ans)):
            if ans[i] >= 0.5:
                ans[i] = 1
            else:
                ans[i] = 0
        return ans
    else:
        y_pre = np.argmax(ans, axis=1)
        return y_pre


def get_accuracy(beta, data_test):
    x, y_test = data_test[:, :-1], data_test[:, -1]
    x_test = np.concatenate([x, np.ones(shape=(x.shape[0], 1))], axis=1)
    ans = np.exp(np.matmul(x_test, beta)) / (1 + np.exp(np.matmul(x_test, beta)))
    y_pre = np.argmax(ans, axis=1)

    accuracy = accuracy_score(y_test, y_pre)
    precision = precision_score(y_test, y_pre, average='macro')
    recall = recall_score(y_test, y_pre, average='macro')
    f1 = f1_score(y_test, y_pre, average='macro')
    conf_matrix = confusion_matrix(y_test, y_pre)

    print(f"准确率: {accuracy}")
    print(f"精确率: {precision}")
    print(f"召回率: {recall}")
    print(f"F1分数: {f1}")

    disp = ConfusionMatrixDisplay(confusion_matrix=conf_matrix)
    disp.plot()
    plt.show()

    return accuracy


if __name__ == "__main__":
    names = [f"feature{i}" for i in range(64)]
    names.append("cat")

    data = pd.read_csv("digitsTrain.csv", names=names)

    beta = np.zeros(shape=(65, 10))
    for i in range(10):
        print(f"\n\n正在学习分类器{i}")
        beta[:, i] = train_i(data, i).reshape(-1)

    get_accuracy(beta, np.array(data))

    data_ = pd.read_csv("digitsTest.csv", names=names)
    get_accuracy(beta, np.array(data_))

    def get_k_fold_data(k, i, data):
        data = np.array(data)
        fold_size = data.shape[0] // k
        data_train = None
        for j in range(k):
            idx = slice(j * fold_size, (j + 1) * fold_size)
            data_part = data[idx, :]
            if j == i:
                data_valid = data_part
            elif data_train is None:
                data_train = data_part
            else:
                data_train = np.concatenate([data_train, data_part], 0)
        return data_train, data_valid

    # k-fold cross validation
    k_fold_data = pd.concat([data, data_])
    indices = list(range(len(k_fold_data)))
    random.shuffle(indices)
    k_fold_data = k_fold_data.iloc[indices, :]

    acc = []
    fold = 10
    beta_i = np.zeros(shape=(65, 10))
    for i in range(fold):
        data_train, data_valid = get_k_fold_data(10, i, k_fold_data)
        for j in range(10):
            beta_i[:, j] = train_i(pd.DataFrame(data_train), j).reshape(-1)
        acc.append(get_accuracy(beta_i, data_valid))
    print("各折模型的正确率", acc)
    print("10折交叉验证的模型正确率为", np.array(acc).mean())
