from XGTree import XGDecisionTree
import numpy as np
import pandas as pd

class MyXGBoost:
    def __init__(self, data, lambd = 0.5, gamma = 5.0, maxDepth = 100, min_sample = 1):
        self.data = data
        self.maxDepth = maxDepth
        self.min_sample = min_sample

        self.base_models = []

        self.lambd = lambd
        self.gamma = gamma

        length_data = len(data)
        self.weights = [1 / length_data for i in range(length_data)]

        self.class_num = len(set(data.iloc[:, -1]))

        self.c = None
        if self.class_num > 2:
            self.c = list(range(self.class_num))
            self.base_models = [[] for i in range(self.class_num)]

    def process_data(self, label):
        data = self.data.copy()
        for i in range(len(data)):
            if data.iloc[i, -1] == label:
                data.iloc[i, -1] = 1
            else:
                data.iloc[i, -1] = -1
        return data

    def fit_(self, data, t, models):
        """
        t
            学习器的数量
        """
        G , H = -2 * data.iloc[:, -1], [2 for i in range(len(data))]
        y_pre = np.zeros(shape = (len(data)))
        y = np.array(data.iloc[:, -1]).reshape(y_pre.shape)
        for i in range(t):
            # 基学习器为决策树
            model = XGDecisionTree(data, G, H, self.gamma, self.lambd, self.maxDepth, self.min_sample)
            # 建立模型
            model.createXGTree()
            # 保存模型
            models.append(model)
            print(f"xgTree {i} done")

            # 更新G  H是二阶导 恒等于2不同更新
            y_pre = y_pre + np.array(model.predict(data.iloc[:, :-1]))
            G = -2 * (y - y_pre)

    def fit(self, t):
        if self.class_num == 2:
            self.fit_(self.data, t, self.base_models)

        else:
            for i in range(self.class_num):
                self.fit_(self.process_data(i), t, self.base_models[i])
                print(f"base classifier {i} done")


    def predict(self, x):
        """

        """
        if self.class_num == 2:
            y_pre = np.zeros(shape = (1, 1))
            for model in self.base_models:
                y_pre = y_pre + np.array(model.predict(x))

            return y_pre
        else:
            y_pre = []
            for i in range(self.class_num):
                models = self.base_models[i]
                y_pre_i = np.zeros(shape = (1, 1))
                for model in models:
                    y_pre_i = y_pre_i + np.array(model.predict(x))

                y_pre.append(y_pre_i.reshape(-1, 1))

            return np.concatenate(y_pre, axis = 1).argmax(axis = 1)

    def get_accuracy(self, data):

        x, y = data.iloc[:, :-1], data.iloc[:, -1]
        y_pre = self.predict(x)

        cor, all = 0, 0
        for i in range(len(y_pre)):
            if y_pre[i] == y[i]:
                cor += 1
            all += 1

        print(f"{cor} out of {all}, acc {cor / all}")

        return cor / all


# names = [f"feature{i}" for i in range(64)]
# names.append("class")
# data2 = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTrain.csv", names = names)
# data_val = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTest.csv", names = names)
#
# xg = MyXGBoost(data2, lambd = 0.4, gamma = 5, maxDepth = 3, min_sample = 5)
# xg.fit(20)
# xg.get_accuracy(data2)
# xg.get_accuracy(data_val)

# imgtrain, imgtest = pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//imageDataset//imageTrain.csv"), pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//imageDataset//imageTest.csv")
# xg = MyXGBoost(imgtrain, lambd = 0.1, gamma = 5, maxDepth = 6, min_sample = 5)
# xg.fit(5)
# xg.get_accuracy(imgtrain)
# xg.get_accuracy(imgtest)

pstrain, pstest = pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//personalityClassificationDataset//personalityTrain.csv"), pd.read_csv("E://JupyterPrograms//MachineLearning//课程设计//personalityClassificationDataset//personalityTest.csv")
xgb_ps = MyXGBoost(pstrain, lambd = 0.5, gamma = 5, maxDepth = 6)
xgb_ps.fit(5)
xgb_ps.get_accuracy(pstrain), xgb_ps.get_accuracy(pstest)