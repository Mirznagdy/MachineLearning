import sympy as sp
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

names = [f"feature{i}" for i in range(64)]
names.append("class")
data2 = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTrain.csv", names = names)
data_val = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTest.csv", names = names)
list1 = pd.DataFrame(list(range(len(data2))))
print(list1.loc[data2.iloc[:, -1] == 1].mean())