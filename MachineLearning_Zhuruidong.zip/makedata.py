import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# y = x + 1

x = np.random.normal(0, 0.6, size = (20))
y = np.random.normal(0, 0.6, size = (20))

x_list = np.concatenate([x + 3, x + 1])
y_list = np.concatenate( [y + 1, y + 4])

cl = np.concatenate([np.zeros(20), np.ones(20)]).reshape(40)
plt.scatter(x_list, y_list, c = cl)
plt.show()
data = np.concatenate([x_list.reshape(-1, 1), y_list.reshape(-1, 1), cl.reshape(-1, 1)], axis = 1)
print(data)

data = pd.DataFrame(data, columns = ["x1", "x2", "class"])
data.to_csv("SVMTest.csv", index=False)