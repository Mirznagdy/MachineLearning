import pandas as pd
import numpy as np
from math import log, exp
import random
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn import tree

class DecisionTreeNode:
    def __init__(self, feature, feature_index, feature_is_continuous, continuous_value = 0):
        """
        初始化
        """
        self.feature = feature
        self.feature_index = feature_index
        self.feature_is_continuous = feature_is_continuous
        self.continuous_value = continuous_value
        self.sons = dict()
        self.leaf_tag = None

class DecisionTree:
    def __init__(self, data):
        self.data = data
        self.features = list(data.iloc[:, :-1].columns)
        self.x = data.iloc[:, :-1]
        self.y = data.iloc[:, -1]
        self.is_continuous = []
        for feature in self.features:
            if (self.data[feature].dtype == "float" or self.data[feature].dtype == "int" or self.data[feature].dtype == "int64"):
                if (len(set(self.data[feature])) > 0.3 * len(self.data)) or len(set(self.data[feature])) > 10:
                    self.is_continuous.append(True)
                else:
                    self.is_continuous.append(False)
            else:
                self.is_continuous.append(False)
        self.dic = dict()

    def info_entropy(self, data_y):
        labels = set(list(data_y))
        y_num = len(data_y)
        Ent_D = 0
        for label in labels:
            pk = len(data_y.loc[data_y == label])
            pk = pk / y_num
            Ent_D = Ent_D - (pk * log(pk, 2))
        return Ent_D

    def Gain(self, data, features_index, Gain_ratio = False):
        """
        该函数接受数据集 返回信息增益最大的属性
        """
        Ent_D = self.info_entropy(data.iloc[:, -1])
        length_data = len(data)
        max_gain = 0
        max_gain_feature_index = features_index[0]
        max_gain_continuous = 0
        for i in features_index:
            feature_name = self.features[i]
            sum_ = 0
            if self.is_continuous[i]:
                sorted_values = list(set(data[feature_name]))
                sorted_values.sort()
                for j in range(len(sorted_values) - 1):
                    _sum = 0
                    v = (sorted_values[j] + sorted_values[j + 1]) / 2
                    _sum = _sum + len(data.loc[data[feature_name] <= v]) / length_data * self.info_entropy(data.loc[data[feature_name] <= v].iloc[:,-1]) + len(data.loc[data[feature_name] > v]) / length_data * self.info_entropy(data.loc[data[feature_name] > v].iloc[:,-1])

                    IV_a = -len(data.loc[data[feature_name] <= v]) / length_data * log(len(data.loc[data[feature_name] <= v]) / length_data, 2) - len(data.loc[data[feature_name] > v]) / length_data * log(len(data.loc[data[feature_name] > v]) / length_data, 2)
                    gain = Ent_D - _sum
                    if Gain_ratio == True:
                        if IV_a == 0:
                            IV_a = 0.00001
                        gain = gain / IV_a

                    if gain > max_gain:
                        max_gain = gain
                        max_gain_feature_index = i
                        max_gain_continuous = v
            else:
                IV_a = 0
                cat_feature = set(list(data[feature_name]))
                for feature in cat_feature:
                    num = len(data[data[feature_name] == feature])
                    sum_ = sum_ + num / length_data * self.info_entropy(data.loc[data[feature_name] == feature].iloc[:, -1])
                    IV_a = IV_a - num / length_data * log(num / length_data, 2)
                gain = Ent_D - sum_
                if Gain_ratio == True:
                    if IV_a == 0:
                        IV_a = 0.00001
                    gain = gain / IV_a
                if gain > max_gain:
                    max_gain = gain
                    max_gain_feature_index = i
        if self.is_continuous[max_gain_feature_index]:
            return self.features[max_gain_feature_index], max_gain_feature_index, True, max_gain_continuous
        else:
            return self.features[max_gain_feature_index], max_gain_feature_index, False

    def best_col(self, data, features_index, method = "Gain"):
        """
        该函数接受数据集和划分的方法，返回最有属性及其下标 是否连续等
        """
        if method == "Gain":
            return self.Gain(data, features_index)
        elif method == "Gain_ratio":
            return self.Gain(data, features_index, True)
        else:
            min_gini = 1000
            min_gini_feature_index = features_index[0]
            min_gini_continuous = 0
            length_data = len(data)
            for i in features_index:
                feature_name = self.features[i]
                if self.is_continuous[i] == True:
                    sorted_values = list(set(data[feature_name]))
                    sorted_values.sort()
                    for j in range(len(sorted_values) - 1):
                        v = (sorted_values[j] + sorted_values[j + 1]) / 2
                        d1, d2 = data.loc[data[feature_name] <= v].iloc[:, -1], data.loc[data[feature_name] > v].iloc[:, -1]
                        length_d1, length_d2 = len(d1), len(d2)
                        d1_list, d2_list = list(set(d1)), list(set(d2))
                        gini1, gini2 = 1, 1
                        for k in d1_list:
                            gini1 = gini1 - (len(d1.loc[d1 == k]) / length_d1) ** 2
                        for k in d2_list:
                            gini2 = gini2 - (len(d2.loc[d2 == k]) / length_d2) ** 2
                        if length_d1 / length_data * gini1 + length_d2 / length_data * gini2 < min_gini:
                            min_gini = length_d1 / length_data * gini1 + length_d2 / length_data * gini2
                            min_gini_feature_index = i
                            min_gini_continuous = v
                else:
                    gini = 0
                    values = list(set(self.data[feature_name]))
                    for value in values:
                        g = 1
                        d = data.loc[data[feature_name] == value].iloc[:, -1]
                        length_d = len(d)
                        k_list = list(set(d))
                        for k in k_list:
                            g = g - (len(d.loc[d == k]) / length_d) ** 2
                        gini = gini + length_d / length_data * g
                    if gini < min_gini:
                        min_gini = gini
                        min_gini_feature_index = i
        if self.is_continuous[min_gini_feature_index] == True:
            return self.features[min_gini_feature_index], min_gini_feature_index, True, min_gini_continuous
        else:
            return self.features[min_gini_feature_index], min_gini_feature_index, False

    def accurate_num(self, y_hat, y):
        cor = 0
        for i in range(len(y)):
            if y_hat == y[i]:
                cor = cor + 1
        return cor

    def is_prep_better(self, default_label, val_data, f, train_data):
        """
        判断是否需要预剪枝
        """
        before_partition = self.accurate_num(y_hat=default_label, y=list(val_data.iloc[:, -1]))
        after_partition = 0
        if f[2] == False:
            values = list(set(self.data[f[0]]))
            for value in values:
                partition_train_data, partition_val_data = train_data.loc[train_data[f[0]] == value], val_data.loc[val_data[f[0]] == value]
                if len(partition_train_data) == 0:
                    dl = default_label
                    after_partition = after_partition + self.accurate_num(y_hat=dl, y=list(partition_val_data.iloc[:, -1]))
                else:
                    dl = partition_train_data.iloc[:, -1].value_counts().idxmax()
                    after_partition = after_partition + self.accurate_num(y_hat=dl, y=list(partition_val_data.iloc[:, -1]))
        else:
            partition_train_data_1, partition_train_data_2 = train_data.loc[train_data[f[0]] <= f[3]], train_data.loc[train_data[f[0]] > f[3]]
            partition_val_data_1, partition_val_data_2 = val_data.loc[val_data[f[0]] <= f[3]], val_data.loc[val_data[f[0]] > f[3]]
            dl1, dl2 = partition_train_data_1.iloc[:, -1].value_counts().idxmax(), partition_train_data_2.iloc[:, -1].value_counts().idxmax()
            after_partition = after_partition + self.accurate_num(y_hat=dl1, y=list(partition_val_data_1.iloc[:, -1]))
            after_partition = after_partition + self.accurate_num(y_hat=dl2, y=list(partition_val_data_2.iloc[:, -1]))
        if after_partition > before_partition:
            return True
        else:
            return False

    def build_tree(self, data, val_data = None, is_pre_pruning = False, method = "Gain"):
        """
        建树
        """
        return self.DFS_build_tree(data, list(range(len(self.features))), val_data, is_pre_pruning, method)

    def DFS_build_tree(self, data, features_index, val_data = None, is_pre_pruning = False, method = "Gain"):
        """
        递归建树
        """
        if len(data.iloc[:, -1].value_counts()) == 1:
            root = DecisionTreeNode(None, None, None)
            root.leaf_tag = data.iloc[:, -1].value_counts().idxmax()
            return root

        if len(features_index) == 0:
            root = DecisionTreeNode(None, None, None)
            root.leaf_tag = data.iloc[:, -1].value_counts().idxmax()
            return root

        f = self.best_col(data, features_index, method)
        root = DecisionTreeNode(f[0], f[1], f[2], f[3])

        if is_pre_pruning == True:
            dl = data.iloc[:, -1].value_counts().idxmax()
            if self.is_prep_better(dl, val_data, f, data) == False:
                root.leaf_tag = dl
                return root
            else:
                if root.feature_is_continuous == False:
                    values = list(set(data[root.feature]))
                    for value in values:
                        partition_data = data.loc[data[root.feature] == value]
                        if len(partition_data) == 0:
                            root.sons[value] = DecisionTreeNode(None, None, None)
                            root.sons[value].leaf_tag = data.iloc[:, -1].value_counts().idxmax()
                        else:
                            root.sons[value] = self.DFS_build_tree(partition_data, [i for i in features_index if i != root.feature_index], val_data.loc[val_data[root.feature] == value], is_pre_pruning, method)
                else:
                    partition_data1, partition_data2 = data.loc[data[root.feature] <= root.continuous_value], data.loc[data[root.feature] > root.continuous_value]
                    root.sons[1] = self.DFS_build_tree(partition_data1, features_index, val_data.loc[val_data[root.feature] <= root.continuous_value], is_pre_pruning, method)
                    root.sons[2] = self.DFS_build_tree(partition_data2, features_index, val_data.loc[val_data[root.feature] > root.continuous_value], is_pre_pruning, method)
        else:
            if root.feature_is_continuous == False:
                values = list(set(data[root.feature]))
                for value in values:
                    partition_data = data.loc[data[root.feature] == value]
                    if len(partition_data) == 0:
                        root.sons[value] = DecisionTreeNode(None, None, None)
                        root.sons[value].leaf_tag = data.iloc[:, -1].value_counts().idxmax()
                    else:
                        root.sons[value] = self.DFS_build_tree(partition_data, [i for i in features_index if i != root.feature_index], val_data, is_pre_pruning, method)
            else:
                partition_data1, partition_data2 = data.loc[data[root.feature] <= root.continuous_value], data.loc[data[root.feature] > root.continuous_value]
                root.sons[1] = self.DFS_build_tree(partition_data1, features_index, val_data, is_pre_pruning, method)
                root.sons[2] = self.DFS_build_tree(partition_data2, features_index, val_data, is_pre_pruning, method)
        return root

    def get_label(self, x, root):
        if root.leaf_tag != None:
            return root.leaf_tag
        if root.feature_is_continuous == False:
            return self.get_label(x, root.sons[x[root.feature]])
        else:
            if x[root.feature] <= root.continuous_value:
                return self.get_label(x, root.sons[1])
            else:
                return self.get_label(x, root.sons[2])

    def predict(self, X):
        result = []
        for i in range(len(X)):
            x = X.iloc[i, :]
            result.append(self.get_label(x, self.root))
        return result

    def fit(self, X_train, y_train, method = "Gain", is_pre_pruning = False, val_data = None):
        self.features = list(X_train.columns)
        self.x = X_train
        self.y = y_train
        self.is_continuous = []
        for feature in self.features:
            if (X_train[feature].dtype == "float" or X_train[feature].dtype == "int" or X_train[feature].dtype == "int64"):
                if (len(set(X_train[feature])) > 0.3 * len(X_train)) or len(set(X_train[feature])) > 10:
                    self.is_continuous.append(True)
                else:
                    self.is_continuous.append(False)
            else:
                self.is_continuous.append(False)
        self.data = pd.concat([X_train, y_train], axis=1)
        self.root = self.build_tree(self.data, val_data, is_pre_pruning, method)
        return self

# 使用示例数据进行模型训练和评估
df = pd.read_csv("watermelon.csv")

# 训练数据
X_train = df.iloc[:, :-1]
y_train = df.iloc[:, -1]

# 使用决策树训练模型
clf = DecisionTree(df)
clf.fit(X_train, y_train, method="Gain_ration")

# 预测
y_pred = clf.predict(X_train)

# 计算准确率、精确率、召回率和F1分数
accuracy = accuracy_score(y_train, y_pred)
precision = precision_score(y_train, y_pred, average="weighted")
recall = recall_score(y_train, y_pred, average="weighted")
f1 = f1_score(y_train, y_pred, average="weighted")

# 打印结果
print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1)

# 绘制混淆矩阵
conf_mat = confusion_matrix(y_train, y_pred)
plt.figure(figsize=(10, 7))
sns.heatmap(conf_mat, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()
