import numpy as np
import pandas as pd
import random

class MyNeuralNetwork:
    def __init__(self, in_features, hidden_layer_features, output_layer_features):
        # 单隐层神经网络的参数
        self.v = np.random.normal(0, 0.1, size = (in_features, hidden_layer_features))
        self.gama = np.zeros(hidden_layer_features).reshape(1, -1)   # 行向量
        self.w = np.random.normal(0, 0.1, size = (hidden_layer_features, output_layer_features))
        self.theta = np.zeros(output_layer_features).reshape(1, -1)  # 行向量
        # print(self.v, self.v.shape, self.gama, self.gama.shape, self.w, self.w.shape, self.theta, self.theta.shape)

    # 对原始数据做简单的预处理
    def preprocess(self, data):
        """
        如果特征是离散的而且不是数字表示，那么就换成离散的特征改成0 1 2...
        """
        for col in data.columns:
            if data[col].dtype == "object":
                values = set(data[col])
                map_dic = dict()
                tag = 0
                for value in values:
                    map_dic[value] = tag
                    tag += 1
                data[col] = data[col].map(map_dic)

    # sigmoid激活函数
    def sigmoid(self, x):
        # print(x)
        return 1 / (1 + np.exp(-x))

    # 把特征和标签随机打算，取一个
    def data_loader(self, x, y):
        ind = list(range(x.shape[0]))
        random.shuffle(ind)
        # 如果是二分类
        if self.w.shape[1] == 1:
            y = y.reshape(-1, 1)
            for i in range(x.shape[0]):
                yield x[ind[i]], y[ind[i]]
        # 多分类
        else:
            for i in range(x.shape[0]):
                y_ = np.zeros(self.w.shape[1])
                y_[y[ind[i]]] = 1
                yield x[ind[i]], y_

    # 把多分类的 y 改成训练要的格式
    def y_modify(self, y):
        ans = np.zeros(shape = (len(y), self.w.shape[1]))
        for i in range(len(y)):
            ans[i, y[i]] = 1
        return ans

    # 均方误差
    def MSEloss(self, x, y):
        y_h = self.sigmoid(np.matmul((np.matmul(x, self.v) - self.gama), self.w) - self.theta)
        loss = (y_h - y) ** 2
        return loss.sum() / 2

    # 标准BP训练过程
    def fit_BP(self, x, y, lr, epochs = 10):
        # 训练轮数
        for epoch in range(epochs):
            for x_k, y_k in self.data_loader(x, y):
                # print(x_k, y_k)
                # 隐藏层计算得到的alpha
                alpha = np.matmul(x_k.reshape(1, -1), self.v)
                # 隐藏层激活后传入输出层的参数b
                b = self.sigmoid(alpha - self.gama)

                #输出层计算得到beta
                beta = np.matmul(b, self.w)
                # 输出层输出值
                y_hat = self.sigmoid(beta - self.theta)

                """
                计算导数g和e
                这里利用numpy.array做加减乘除即是对对应元素加减乘除的特点免去了写循环
                后面更新w, v, gama, theta都利用了这个特性
                """
                g = y_hat * (1 - y_hat) * (y_k - y_hat)
                e = b * (1 - b) * np.matmul(self.w, g.reshape(-1, 1)).reshape(1, -1)

                # print(num, "\n", np.matmul(b.reshape(-1, 1), g), "\n\n", g)
                # 根据公式更新 w, theta
                self.w = self.w + lr * np.matmul(b.reshape(-1, 1), g)
                self.theta = self.theta - lr * g

                # print("\n", np.matmul(x_k.reshape(-1, 1), e), "\n\n", e)
                # 根据公式更新 v, beta
                self.v = self.v + lr * np.matmul(x_k.reshape(-1, 1), e)
                self.gama = self.gama - lr * e
            # 打印过程信息
            print(f"epoch{epoch}  loss {self.MSEloss(x, self.y_modify(y))}")

    # 累计BP训练过程
    def fit_ABP(self, x, y, lr, epochs=10):
        """
        累计BP的损失是标准BP的单个损失求和
        根据求导的法则，累计BP的损失函数关于各个参数的导数是标准BP的导数在对样本求和
        """
        # 将y修改成训练需要的形式
        y = self.y_modify(y)
        for epoch in range(epochs):

            alpha = np.matmul(x, self.v)
            """
            这里alpha - gama利用了numpy的广播机制
            两个array做加减乘除，如果形状不同，会把形状小的自我复制是两个array形状相同
            """
            b = self.sigmoid(alpha - self.gama)

            beta = np.matmul(b, self.w)
            # 同样利用广播机制
            y_hat = self.sigmoid(beta - self.theta)

            # 这里g 和 e都是矩阵，第k行表示第k个样本的g e向量
            g = y_hat * (1 - y_hat) * (y - y_hat)
            e = b * (1 - b) * np.matmul(g, self.w.T)

            # 根据公式更新参数 和标准BP不同的是这里多了对样本求和
            self.w = self.w + lr * np.matmul(b.T, g)
            self.theta = self.theta - lr * g.sum(axis = 0)

            #根据公式更新参数 和标准BP不同的是这里多了对样本求和
            self.v = self.v + lr * np.matmul(x.T, e)
            self.gama = self.gama - lr * e.sum(axis = 0)
    # def fit_no(self, x, y, lr, epochs):
    #     for epoch in range(epochs):
    #         alpha, beta, y_hat_k = np.zeros(self.v.shape[1]), np.zeros(self.w.shape[1]), np.zeros(self.w.shape[1])
    #         b = np.zeros(self.v.shape[1])
    #         g, e = np.zeros(self.w.shape[1]), np.zeros(self.v.shape[1])
    #         num = 0
    #         for x_k, y_k in self.data_loader(x, y):
    #             print(num)
    #             num += 1
    #             for j in range(len(y_k)):
    #
    #                 sigma_w_b = 0
    #                 for h in range(self.w.shape[0]):
    #                     sigma_v_x = 0
    #                     for i in range(self.v.shape[0]):
    #                         sigma_v_x = sigma_v_x + self.v[i, h] * x_k[i]
    #                     alpha[h] = sigma_v_x - self.gama[h]
    #                     b[h] = self.sigmoid(alpha[h])
    #
    #                     sigma_w_b = sigma_w_b + self.w[h, j] * b[h]
    #                 beta[j] = sigma_w_b - self.theta[j]
    #                 y_hat_k[j] = self.sigmoid(beta[j])
    #
    #             for j in range(len(y_k)):
    #                 g[j] = y_hat_k[j] * (1 - y_hat_k[j]) * (y_k[j] - y_hat_k[j])
    #
    #             for h in range(self.w.shape[0]):
    #                 sigma_w_g = 0
    #                 for j in range(len(y_k)):
    #                     sigma_w_g = sigma_w_g + self.w[h, j] * g[j]
    #                 e[h] = b[h] * (1 - b[h]) * sigma_w_g
    #
    #             for j in range(self.w.shape[1]):
    #                 for h in range(self.w.shape[0]):
    #                     self.w[h, j] = self.w[h, j] + lr * g[j] * b[h]
    #                 self.theta[j] = self.theta[j] - lr * g[j]
    #
    #             for h in range(self.v.shape[1]):
    #                 for i in range(self.v.shape[0]):
    #                     self.v[i, h] = self.v[i, h] + lr * e[h] * x_k[i]
    #                 self.gama[h] = self.gama[h] - lr * e[h]
    #         print("epoch", epoch)

    # 模型训练函数
    # 训练函数对外接口
    def fit(self, data, method = "BP", lr = 0.01, epochs = 10):
        assert method == "BP" or method == "ABP", f"没有\"{method}\"方法，可以选择BP或ABP，默认为BP"

        # 先预处理数据
        self.preprocess(data)
        # 如果用标准BP
        if method == "BP":
            self.fit_BP(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]), lr, epochs)
            # print(self.w, self.theta, self.v, self.gama)
            self.get_accuracy(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))
        # 如果用ABP
        elif method == "ABP" :
            self.fit_ABP(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]), lr, epochs)
            self.get_accuracy(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))

    # 计算精确度
    def get_accuracy(self, x, y):

        y_h = self.sigmoid(np.matmul((np.matmul(x, self.v) - self.gama), self.w) - self.theta)
        y_hat = np.argmax(y_h, axis=1)
        cor = 0
        if self.w.shape[1] == 1:
            for i in range(len(y)):
                if y_h[i] >= 0.5 and y[i] == 1:
                    cor += 1
                elif y_h[i] < 0.5 and y[i] == 0:
                    cor += 1
        else:
            for i in range(len(y)):
                # print(y_h[i], y[i])
                if y_hat[i] == y[i]:
                    cor += 1
        print(f"{cor} out of {len(y)}, acc {cor / len(y)}")

# data = pd.read_csv("watermelon.csv")
# data = data.iloc[:, 1:]
data = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTrain.csv")
mnw = MyNeuralNetwork(64, 128, 10)
mnw.fit(data, method = "ABP", lr = 0.0001, epochs=300)


data_val = pd.read_csv("E:\\学习\\学习\\机器学习\\第二次编程\\digitsTest.csv")
mnw.get_accuracy(np.array(data_val.iloc[:, :-1]), np.array(data_val.iloc[:, -1]))
