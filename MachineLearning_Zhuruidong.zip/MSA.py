import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False
import sklearn.cluster
import seaborn as sns
from scipy.cluster.hierarchy  import linkage
import scipy.cluster.hierarchy as sc

data1 = pd.read_excel("E:\\JupyterPrograms\\MultivariateStatisticalAnalysis\\上机1\\EXE3_1.xls", index_col = 0)
sns.clustermap(data1, metric = 'euclidean', method='single', cmap = "Blues", standard_scale = 1)
plt.show()
Z1 = linkage(data1, method = "single", metric = "euclidean")
sc.dendrogram(Z1, labels = data1.index, leaf_rotation = 0, orientation = "left", leaf_font_size = 7, color_threshold = None, above_threshold_color = "blue")
plt.show()