import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


def plot_confusion_matrix_and_metrics(tp, fp, tn, fn):
    # Create confusion matrix
    confusion_matrix = np.array([[tp, fp],
                                 [fn, tn]])

    # Define labels
    labels = ['1', '0']

    # Create a heatmap
    sns.heatmap(confusion_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=labels, yticklabels=labels)

    # Add labels and title
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.title('Confusion Matrix')

    # Show the plot
    plt.show()

    # Calculate metrics
    accuracy = (tp + tn) / (tp + fp + tn + fn)
    precision = tp / (tp + fp) if (tp + fp) != 0 else 0
    recall = tp / (tp + fn) if (tp + fn) != 0 else 0
    f1_score = (2 * precision * recall) / (precision + recall) if (precision + recall) != 0 else 0

    # Print metrics
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall: {recall:.4f}")
    print(f"F1 Score: {f1_score:.4f}")


# Example usage
tp = 8
fp = 1
tn = 9
fn = 0

plot_confusion_matrix_and_metrics(tp, fp, tn, fn)
