import pandas as pd
import numpy as np
from BaseModelDecisionTree import BaseModelDecisionTree
import random

class Bagging:
    def __init__(self, data, maxDepth = 1):
        self.data = data
        self.maxDepth = maxDepth

        self.models = []
        self.class_num = len(set(data.iloc[:, -1]))
        self.length_data = len(data)
        self.weight = [1 / self.length_data for i in range(self.length_data)]

    def sampling(self):
        """自助采样"""
        data_sampled = []
        for i in range(self.length_data):
            # 每次从 0-len 中随机采样一个整数
            data_sampled.append(random.randint(0, self.length_data - 1))
        # print(data_sampled)
        return self.data.iloc[data_sampled, :].reset_index(drop=True)

    def fit(self, t):
        for i in range(t):
            data_sampled = self.sampling()
            # 直接用决策树作为基学习器
            self.models.append(BaseModelDecisionTree(data_sampled, self.weight, self.maxDepth))
            self.models[i].createTree()

    def predict(self, x):
        ans = []
        y_pre = []
        for model in self.models:
            # 获得每个基学习器的预测结果 reshape成列向量的形式
            ans.append(np.array(model.predict(x)).reshape(-1, 1))
        # 把每个基学习器预测结果排列成一个矩阵
        res = np.concatenate(ans, axis = 1)
        for line in res:
            # append每一行出现最多的类
            y_pre.append(np.argmax(np.bincount(line)))
        return y_pre

    def get_accuracy(self, data):
        y_pre = self.predict(data.iloc[:, :-1])
        cor, all = 0, len(data)
        for i in range(len(y_pre)):
            if y_pre[i] == data.iloc[i, -1]:
                cor += 1
        print(f"{cor} out of {all}, acc {cor / all}")
        return cor / all



watermelon_data = pd.read_csv("watermelon3_0.csv")
watermelon_data = watermelon_data.iloc[:, 7:]
watermelon_data["好瓜"] = watermelon_data["好瓜"].map({"是" : 1, "否" : 0})
# print(watermelon_data.info)
# # print(watermelon_data.iloc[[0, 1, 1], :])
#
bag = Bagging(watermelon_data, 10)
bag.fit(20)
#
# print(bag.predict(watermelon_data.iloc[:, :-1]))
bag.get_accuracy(watermelon_data)

