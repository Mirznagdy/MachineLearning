import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score

class SVM:
    def __init__(self):
        self.w = None
        self.b = np.zeros(1)
        self.x = None
        self.num_class = 0

    def x_dot_x(self, index1, index2, kernel="linear", **kwargs):
        xi_T_xj = (self.x[index1, :] * self.x[index2, :]).sum()
        normal_xi_xj = ((self.x[index1, :] - self.x[index2,:])**2).sum()
        if kernel == "linear":
            return xi_T_xj
        elif kernel == "polynomial":
            return xi_T_xj ** kwargs["d"]
        elif kernel == "Gauss":
            return np.exp(-normal_xi_xj / (2 * kwargs["sigma"] * kwargs["sigma"]))
        elif kernel == "Laplace":
            return np.exp(-np.sqrt(normal_xi_xj) / kwargs["sigma"])
        elif kernel == "Sigmoid":
            return np.tanh(kwargs["beta"] * xi_T_xj + kwargs["theta"])

    def sampleJ(self, i, m):
        j = i
        while j == i:
            j = int(np.random.uniform(0, m))
        return j

    def modify_alpha(self, aj, L, H):
        if aj <= L:
            aj = L
        elif aj >= H:
            aj = H
        return aj

    def fit_(self, x, y, C=100, toler=0.001, epochs=10, kernel="linear", **kwargs):
        b = 0
        m, n = x.shape
        alpha = np.zeros(m).reshape(m, 1)
        epoch = 0
        while epoch < epochs:
            alphaChanged = 0
            for i in range(m):
                fx_i = (np.multiply(alpha, y) * np.matmul(x, x[i, :].reshape(-1, 1))).sum(axis=0) + b
                Ei = fx_i - y[i]
                if ((y[i] * fx_i < 1) and (alpha[i] < C)) or ((y[i] * fx_i > 1) and (alpha[i] > 0)):
                    j = self.sampleJ(i, m)
                    fx_j = (np.multiply(alpha, y) * np.matmul(x, x[j, :].reshape(-1, 1))).sum(axis=0) + b
                    Ej = fx_j - y[j]
                    alpha_i_old, alpha_j_old = alpha[i].copy(), alpha[j].copy()
                    if y[i] != y[j]:
                        L = max(0, alpha[j] - alpha[i])
                        H = min(C, C + alpha[j] - alpha[i])
                    else:
                        L = max(0, alpha[j] + alpha[i] - C)
                        H = min(C, alpha[j] + alpha[i])
                    if L == H:
                        continue
                    eta = 2 * self.x_dot_x(i, j, kernel=kernel, **kwargs) - self.x_dot_x(i, i, kernel=kernel, **kwargs) - self.x_dot_x(j, j, kernel=kernel, **kwargs)
                    if eta >= 0:
                        continue
                    alpha[j] -= y[j] * (Ei - Ej) / eta
                    alpha[j] = self.modify_alpha(alpha[j], L, H)
                    if np.abs(alpha[j] - alpha_j_old) < 0.000001:
                        continue
                    alpha[i] += y[j] * y[i] * (alpha_j_old - alpha[j])
                    b1 = b - Ei - y[i] * (alpha[i] - alpha_i_old) * self.x_dot_x(i, i, kernel=kernel, **kwargs) - y[j] * (alpha[j] - alpha_j_old) * self.x_dot_x(i, j, kernel=kernel, **kwargs)
                    b2 = b - Ej - y[i] * (alpha[i] - alpha_i_old) * self.x_dot_x(i, j, kernel=kernel, **kwargs) - y[j] * (alpha[j] - alpha_j_old) * self.x_dot_x(j, j, kernel=kernel, **kwargs)
                    if (alpha[i] > 0) and (alpha[i] < C):
                        b = b1
                    elif (alpha[j] > 0) and (alpha[j] < C):
                        b = b2
                    else:
                        b = (b1 + b2) / 2
                    alphaChanged += 1
            epoch += 1
        w = (alpha * y * x).sum(axis=0)
        return w, b

    def dataY_for_classi(self, y, i):
        y_ = np.ones(shape=y.shape)
        for index in range(len(y)):
            if y[index] != i:
                y_[index] = -1
        return y_

    def fit(self, x, y, C=100, toler=0.001, epochs=10, kernel="linear", **kwargs):
        self.num_class = len(set(y))
        self.x = x
        self.w, self.b = np.zeros(shape=(x.shape[1], self.num_class)), np.zeros(shape=(1, self.num_class))
        if self.num_class > 2:
            for i in range(self.num_class):
                y_i = self.dataY_for_classi(y, i).reshape(-1, 1)
                self.w[:, i], self.b[:, i] = self.fit_(x, y_i, C, toler, epochs, kernel, **kwargs)
                print(f"SVM for class {i} is Done")
        else:
            y_i = self.dataY_for_classi(y, 1).reshape(-1, 1)
            self.w, self.b = self.fit_(x, y_i, C, toler, epochs, kernel, **kwargs)

    def predict(self, X):
        y_pre = np.matmul(X, self.w) + self.b
        if self.num_class == 2:
            for i in range(len(y_pre)):
                if y_pre[i] >= 0:
                    y_pre[i] = 1
                else:
                    y_pre[i] = 0
        else:
            y_pre = y_pre.argmax(axis=1)
        return y_pre

    def evaluate(self, X, y):
        y_pre = self.predict(X)
        accuracy = accuracy_score(y, y_pre)
        precision = precision_score(y, y_pre, average='weighted')
        recall = recall_score(y, y_pre, average='weighted')
        f1 = f1_score(y, y_pre, average='weighted')
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"F1 Score: {f1:.4f}")

        cm = confusion_matrix(y, y_pre)
        print("Confusion Matrix:")
        print(cm)
        plt.figure(figsize=(8, 6))
        plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        plt.title('Confusion Matrix')
        plt.colorbar()
        tick_marks = np.arange(len(set(y)))
        plt.xticks(tick_marks, tick_marks)
        plt.yticks(tick_marks, tick_marks)
        plt.ylabel('True label')
        plt.xlabel('Predicted label')
        plt.show()

if __name__ == "__main__":
    names = [f'feature{i}' for i in range(64)]
    names.append("class")
    data = pd.read_csv("digitsTrain.csv", names=names)
    svm = SVM()

    x, y = np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1])
    svm.fit(x, y, C=5, toler=1, epochs=30, kernel="Gauss", sigma=1)

    data_val = pd.read_csv("digitsTest.csv", names=names)
    print("Training Data Evaluation:")
    svm.evaluate(np.array(data.iloc[:, :-1]), np.array(data.iloc[:, -1]))
    print("Validation Data Evaluation:")
    svm.evaluate(np.array(data_val.iloc[:, :-1]), np.array(data_val.iloc[:, -1]))
