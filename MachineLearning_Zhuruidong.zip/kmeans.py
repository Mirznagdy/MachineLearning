import time
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import f1_score, accuracy_score, normalized_mutual_info_score, adjusted_rand_score
from sklearn.preprocessing import LabelEncoder
from sklearn.decomposition import PCA

# 加载数据集
iris = pd.read_csv("iris.csv", header=0)
features = iris.columns[:-1]  # 特征名
dataset = iris[features].values  # 特征数据
original_labels = iris[iris.columns[-1]].values  # 原始标签

# 初始化质心
def initialize_centroids(data, k):
    return data[np.random.choice(data.shape[0], k, replace=False)]

# 分配簇
def get_clusters(data, centroids):
    distances = np.linalg.norm(data[:, np.newaxis] - centroids, axis=2)
    return np.argmin(distances, axis=1)

# 更新质心
def update_centroids(data, cluster_labels, k):
    return np.array([data[cluster_labels == i].mean(axis=0) for i in range(k)])

# K均值算法
def k_means(data, k, T, epsilon):
    start = time.time()
    centroids = initialize_centroids(data, k)
    for t in range(T):
        cluster_labels = get_clusters(data, centroids)
        new_centroids = update_centroids(data, cluster_labels, k)
        if np.linalg.norm(new_centroids - centroids) < epsilon:
            break
        centroids = new_centroids
        print(f"第 {t} 次迭代")
    print(f"用时：{time.time() - start}")
    return cluster_labels, centroids

def clustering_indicators(labels_true, labels_pred):
    if type(labels_true[0]) != int:
        labels_true = LabelEncoder().fit_transform(labels_true)
    f_measure = f1_score(labels_true, labels_pred, average='macro')
    accuracy = accuracy_score(labels_true, labels_pred)
    normalized_mutual_information = normalized_mutual_info_score(labels_true, labels_pred)
    rand_index = adjusted_rand_score(labels_true, labels_pred)
    return f_measure, accuracy, normalized_mutual_information, rand_index

# 绘制聚类结果散点图
def draw_cluster(dataset, centers, labels):
    if dataset.shape[1] > 2:
        pca = PCA(n_components=2)
        dataset = pca.fit_transform(dataset)
        centers = pca.transform(centers)
    plt.scatter(dataset[:, 0], dataset[:, 1], c=labels, cmap='viridis', s=7)
    plt.scatter(centers[:, 0], centers[:, 1], c='red', s=30, marker='x')
    plt.show()

if __name__ == "__main__":
    k = 3
    T = 100
    epsilon = 1e-5
    labels, centers = k_means(dataset, k, T, epsilon)
    F_measure, ACC, NMI, RI = clustering_indicators(original_labels, labels)
    print(f"F_measure: {F_measure}, ACC: {ACC}, NMI: {NMI}, RI: {RI}")
    draw_cluster(dataset, centers, labels)
