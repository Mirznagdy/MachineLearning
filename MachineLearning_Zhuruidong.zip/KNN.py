import pandas as pd
import numpy as np

class KNN:
    def __init__(self, data):
        self.data = data
        self.x = np.array(data.iloc[:, :-1])
        self.y = list(data.iloc[:, -1])

        self.labels = list(set(self.y))

    def get_label(self, lst):
        """
        lst:
            [(label1, dist1), (label2, dist2), ...(labelk, distk)]
        """
        ans = []
        # 将lst数组离的标签信息分离出来单独存在ans里
        for label, dist in lst:
            ans.append(label)
        dic = {}
        lb = self.labels[0]
        lb_count = 0
        # 遍历每一种标签
        for label in self.labels:
            # 计算类别label出现的次数
            ct = ans.count(label)
            # 如果该label出现的次数更多
            if ans.count(label) >= lb_count:
                lb = label
                lb_count = ct

        return lb





    def predict_(self, x, k):
        # 该函数获取单个样本x的KNN类
        n = self.x.shape[0] # 训练样本数量
        # ans用来存放距离从小到大排列好的K个训练样本
        ans = []
        for i in range(n):
            # 计算训练样本到该样本的欧氏距离
            dist = ((x - self.x[i, :])**2).sum()

            index = 0
            for j in range(len(ans) - 1, -1, -1):
                # 寻找第j个样本的插入位置
                if dist < ans[j][1]:
                    index = j
                else:
                    break
            # 如果ans里还不到k个样本 直接插入
            if len(ans) < k:
                ans.insert(index, (self.y[i], dist))
            # 如果ans里已有k个样本 但是还得插入 那就先插入再把末尾的删除
            elif len(ans) == k and dist < ans[-1][1]:
                ans.insert(index, (self.y[i], dist))
                del ans[-1]

        return self.get_label(ans)

    def predict(self, x, k):
        x = np.array(x)     # 转化成numpy类型方便计算
        # 检查预测样本是否只有一个
        try:
            x.shape[1]
        except:
            x = x.reshape(1, -1)

        n = x.shape[0]
        y_pre = []      # 结果保存
        for i in range(n):
            # 对每一个样本调用 self.predict_()函数
            y_pre.append(self.predict_(x[i, :], k))

        return y_pre

    def get_accuracy(self, data, k):
        x, y = np.array(data.iloc[:, :-1]), data.iloc[:, -1]

        y_pre = self.predict(x, k)
        cor, all = 0, 0
        for i in range(len(y_pre)):
            if y_pre[i] == y[i]:
                cor += 1

            all += 1

        print(f"{cor} out of {all}, acc {cor / all}")


if __name__ == "__main__":
    names = [f"feature{i}" for i in range(64)]
    names.append("class")
    data2 = pd.read_csv("digitsTrain.csv", names = names)
    data_val = pd.read_csv("digitsTest.csv", names = names)

    knn = KNN(data2)
    knn.get_accuracy(data2, 10)
    knn.get_accuracy(data_val, 10)
